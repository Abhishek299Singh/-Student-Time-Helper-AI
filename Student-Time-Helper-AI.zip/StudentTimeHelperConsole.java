import java.util.*;

public class StudentTimeHelperConsole {
    static Scanner sc = new Scanner(System.in);
    static ArrayList<String> tasks = new ArrayList<>();

    public static void main(String[] args) {
        System.out.println("📚 Welcome to Student Time Management Helper with Friend AI!");

        int choice;
        do {
            System.out.println("\nMain Menu:");
            System.out.println("1. Add a task");
            System.out.println("2. View all tasks");
            System.out.println("3. Chat with Friend AI");
            System.out.println("4. Exit");
            System.out.print("Choose an option: ");
            choice = sc.nextInt();
            sc.nextLine(); // clear input buffer

            switch (choice) {
                case 1:
                    addTask();
                    break;
                case 2:
                    viewTasks();
                    break;
                case 3:
                    friendChat();
                    break;
                case 4:
                    System.out.println("Goodbye! Stay productive. 👋");
                    break;
                default:
                    System.out.println("Invalid choice. Please select again.");
            }

        } while (choice != 4);
    }

    static void addTask() {
        System.out.print("Enter your task: ");
        String task = sc.nextLine().trim();
        if (!task.isEmpty()) {
            tasks.add(task);
            System.out.println("✅ Task added!");
        } else {
            System.out.println("❌ Task can't be empty.");
        }
    }

    static void viewTasks() {
        if (tasks.isEmpty()) {
            System.out.println("📭 No tasks added yet.");
        } else {
            System.out.println("📋 Your Tasks:");
            for (int i = 0; i < tasks.size(); i++) {
                System.out.println((i + 1) + ". " + tasks.get(i));
            }
        }
    }

    static void friendChat() {
        System.out.println("💬 Start chatting with your Friend AI (type 'exit' to stop):");

        while (true) {
            System.out.print("You: ");
            String input = sc.nextLine().toLowerCase();

            if (input.equals("exit")) {
                break;
            }

            String response = getAIResponse(input);
            System.out.println("Friend AI: " + response);
        }
    }

    static String getAIResponse(String input) {
        if (input.contains("tired")) {
            return "Take a short break and refresh your mind! 🧘";
        } else if (input.contains("study")) {
            return "Nice! Keep that study streak going. 📘";
        } else if (input.contains("motivate")) {
            return "You're doing great. Just keep going 💪";
        } else if (input.contains("help")) {
            return "I can help you with task tracking and motivation!";
        } else {
            return "I'm here for you! Let's make the most of your time 😊";
        }
    }
}