# Student Time Management Helper with Friend AI

A simple Java console project to help students stay productive by managing tasks and chatting with a friendly AI chatbot.

## Features

- Add and view tasks in memory
- Friendly AI chatbot for motivation
- Menu-driven console UI
- 100% Java — no external libraries

## How to Run

1. Open an online Java compiler (like OnlineGDB or Programiz)
2. Paste the code from `StudentTimeHelperConsole.java`
3. Run the program and follow the on-screen instructions

## Author

**Abhishek Singh** – 1st Year, YCCE Nagpur

---